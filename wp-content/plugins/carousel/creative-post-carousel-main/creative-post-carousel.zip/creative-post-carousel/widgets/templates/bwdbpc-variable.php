

<div class="bwdbpc-for-all-owlCarousel"
    bwdbpc-data-margin="<?php echo esc_attr( $bwdbpc_slide_margin );?>"
    bwdbpc-data-desktop="<?php echo esc_attr( $bwdbpc_slide_desktop_view );?>"
    bwdbpc-data-tablet="<?php echo esc_attr( $bwdbpc_slide_tablet_view );?>"
    bwdbpc-data-mobile="<?php echo esc_attr( $bwdbpc_slide_mobile_view );?>"

    bwdbpc-data-autoplay="<?php echo esc_attr( $bwdbpc_infinite_autoplay_switcher );?>"
    bwdbpc-data-loop="<?php echo esc_attr( $bwdbpc_infinite_loop_switcher );?>"
    bwdbpc-data-hoverpause="<?php echo esc_attr( $bwdbpc_HoverPause_switcher );?>"
    bwdbpc-data-centermode="<?php echo esc_attr( $bwdbpc_centermode_switcher );?>"
    bwdbpc-data-timeout="<?php echo esc_attr( $bwdbpc_autoplay_timeout );?>"
    bwdbpc-data-autospeed="<?php echo esc_attr( $bwdbpc_autoplay_speed );?>"
    bwdbpc-data-stagepadding ="<?php echo esc_attr( $bwdbpc_stace_padding );?>"

    bwdbpc-data-navigations="<?php echo esc_attr( $bwdbpc_nav_switcher );?>"
    bwdbpc-data-navtype="<?php echo esc_attr( $bwdbpc_nav_type );?>"
    bwdbpc-data-navprev="<?php echo esc_attr( $prev );?>"
    bwdbpc-data-navnext="<?php echo esc_attr( $next );?>"

    bwdbpc-data-dots="<?php echo esc_attr( $bwdbpc_dots_switcher );?>"
    bwdbpc-data-dotstype="<?php echo esc_attr( $bwdbpc_dots_type );?>"></div>