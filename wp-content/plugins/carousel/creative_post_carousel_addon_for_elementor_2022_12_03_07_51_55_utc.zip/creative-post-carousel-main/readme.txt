Documentation
==============
Open the index.html file within the Documentation folder to learn more about this plugin.

Support
==============
For support questions please send an email to info@bestwpdeveloper.com or put a comment on product page on envato market.