<?php 
if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly.
}
/*
 * @package kontakt
 * since 1.0.0
 * 
*/

//contact form 7 post
if ( ! function_exists( 'kontakt_contact_form_7_posts' ) ) :
  function kontakt_contact_form_7_posts(){
  $args = array('post_type' => 'wpcf7_contact_form', 'posts_per_page' => -1);
    $catlist=[];
    
    if( $categories = get_posts($args)){
        foreach ( $categories as $category ) {
            (int)$catlist[$category->ID] = $category->post_title;
        }
    }
    else{
        (int)$catlist['0'] = esc_html__('No contect From 7 form found', 'kontakt');
    }
  return $catlist;
  }
endif;

 ?>