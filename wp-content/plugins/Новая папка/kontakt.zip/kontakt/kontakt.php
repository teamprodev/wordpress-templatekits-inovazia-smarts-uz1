<?php 
/**
 * Kontakt
 *
 * @package     Kontakt
 * @author      smsoft05
 * @copyright   2020 smsoft05
 * @license     GPL-2.0-or-later
 *
 * Plugin Name: Kontakt
 * Plugin URI:  http://kiwilab.co.nz/agence/2020/02/14/kontakt-2/
 * Description: Kontakt is a nice plugin to diplay contact form 7 anywhere. By this plugin anyone 	can display contact form with elementor widget and WordPress default widget.
 * Version:     1.0.0
 * Author:      smsoft05
 * Author URI:  https://profiles.wordpress.org/quazisazzad/
 * Text Domain: kontakt
 * License:     GPL v2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 *
 */


if( !defined( 'ABSPATH' ) ) {
    die;
}


/*
 * Define Plugin Dir Path
 * @since 1.0.0
 * */
define('KONTAKT_ROOT_PATH',plugin_dir_path(__FILE__));
define('KONTAKT_ROOT_URL',plugin_dir_url(__FILE__));
define('KONTAKT_INC',KONTAKT_ROOT_PATH .'/inc');
define('KONTAKT_CSS',KONTAKT_ROOT_URL .'assets/css');
define('KONTAKT_JS',KONTAKT_ROOT_URL .'assets/js');
define('KONTAKT_ELEMENTOR',KONTAKT_ROOT_PATH .'/elementor');


/** Plugin version **/
define('KONTAKT_VERSION','1.0.0');



  
/**
 * Load plugin textdomain.
 */
add_action( 'plugins_loaded', 'kontakt_textdomain' );
if ( ! function_exists( 'kontakt_textdomain' ) ) {

	function kontakt_textdomain() {
	   load_plugin_textdomain( 'kontakt', false, plugin_basename( dirname( __FILE__ ) ) . '/language' ); 
	}

}

/*
 * require file
*/
if ( file_exists( KONTAKT_INC.'/functions.php' ) ){
	require_once KONTAKT_INC.'/functions.php';
	}

if ( file_exists( KONTAKT_INC.'/functions.php' ) ){
	require_once KONTAKT_ROOT_PATH.'/widget/widget.php';
	}

if ( file_exists( KONTAKT_ELEMENTOR.'/elementor-widgets-init.php' ) ){
	 require_once KONTAKT_ELEMENTOR.'/elementor-widgets-init.php';
	}

if ( file_exists( KONTAKT_ROOT_PATH.'/lib/tgma/activate.php' ) ){
 	  require_once KONTAKT_ROOT_PATH.'/lib/tgma/activate.php';
}


