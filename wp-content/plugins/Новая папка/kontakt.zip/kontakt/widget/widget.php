<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/*
* widget classs
*/

if ( !class_exists( 'Kontakt_Widget' ) ){
class Kontakt_Widget extends WP_Widget {

	private $widget_fields;

	function __construct() {

		$this->widget_fields = array(
			array(
				'label' => esc_html__( 'Select Shortcode', 'kontakt' ),
				'id' => 'selectcontact_select',
				'type' => 'select',
				'options' =>kontakt_contact_form_7_posts(),
			),
		);

		parent::__construct(
			'kontakt_widget',
			esc_html__( 'Contact Widget', 'kontakt' ),
			array( 'description' => esc_html__( 'Display Contact Form 7 In widget', 'kontakt' ), ) // Args
		);

	
	}



	public function widget( $args, $instance ) {
		echo $args['before_widget'];

		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
		}

		echo do_shortcode('[contact-form-7 id="' . $instance['selectcontact_select'] . '"]'); 
		
		echo $args['after_widget'];
	}

	public function field_generator( $instance ) {
		$output = '';
		foreach ( $this->widget_fields as $widget_field ) {
			$default = '';
			if ( isset($widget_field['default']) ) {
				$default = $widget_field['default'];
			}
			$widget_value = ! empty( $instance[$widget_field['id']] ) ? $instance[$widget_field['id']] :'';
			switch ( $widget_field['type'] ) {
				case 'select':
					$output .= '<p>';
					$output .= '<label for="'.esc_attr( $this->get_field_id( $widget_field['id'] ) ).'">'.esc_attr( $widget_field['label'] ).':</label>';
					$output .= '<select id="'.esc_attr( $this->get_field_id( $widget_field['id'] ) ).'" name="'.esc_attr( $this->get_field_name( $widget_field['id'] ) ).'">';
					foreach ($widget_field['options'] as $key => $option) {
						if ($widget_value == $option) {
							$output .= '<option value="'.$key.'" selected>'.$option.'</option>';
						} else {
							$output .= '<option value="'.$key.'">'.$option.'</option>';
						}
					}
					$output .= '</select>';
					$output .= '</p>';
					break;
				default:
					$output .= '<p>';
					$output .= '<label for="'.esc_attr( $this->get_field_id( $widget_field['id'] ) ).'">'.esc_attr( $widget_field['label'], 'kontakt' ).':</label> ';
					$output .= '<input class="widefat" id="'.esc_attr( $this->get_field_id( $widget_field['id'] ) ).'" name="'.esc_attr( $this->get_field_name( $widget_field['id'] ) ).'" type="'.$widget_field['type'].'" value="'.esc_attr( $widget_value ).'">';
					$output .= '</p>';
			}
		}
		echo $output;
	}

	public function form( $instance ) {
		$title = ! empty( $instance['title'] ) ? $instance['title'] : '';
		 if ( function_exists('wpcf7')) {
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_attr_e( 'Title:', 'kontakt' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<?php
		$this->field_generator( $instance );
	   }else{
	   	echo wp_kses( __('<strong>Contact Form 7</strong> is not activated on your site. Please activate <strong>Contact Form 7</strong> first.', 'kontakt'), array( '<strong' ));
	   }
	}

	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		foreach ( $this->widget_fields as $widget_field ) {
			switch ( $widget_field['type'] ) {
				default:
					$instance[$widget_field['id']] = ( ! empty( $new_instance[$widget_field['id']] ) ) ? strip_tags( $new_instance[$widget_field['id']] ) : '';
			}
		}
		return $instance;
	}
}

function kontakt_register_widget() {
	register_widget( 'Kontakt_Widget' );
}
add_action( 'widgets_init', 'kontakt_register_widget' );


}